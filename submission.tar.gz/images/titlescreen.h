/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 titlescreen titlescreen.png 
 * Time-stamp: Sunday 11/07/2021, 16:39:20
 * 
 * Image Information
 * -----------------
 * titlescreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREEN_H
#define TITLESCREEN_H

extern const unsigned short titlescreen[38400];
#define TITLESCREEN_SIZE 76800
#define TITLESCREEN_LENGTH 38400
#define TITLESCREEN_WIDTH 240
#define TITLESCREEN_HEIGHT 160

#endif

