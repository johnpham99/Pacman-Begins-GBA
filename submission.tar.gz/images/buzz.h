/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize 100x100 buzz buzz.png 
 * Time-stamp: Monday 11/08/2021, 19:26:07
 * 
 * Image Information
 * -----------------
 * buzz.png 100@100
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BUZZ_H
#define BUZZ_H

extern const unsigned short buzz[10000];
#define BUZZ_SIZE 20000
#define BUZZ_LENGTH 10000
#define BUZZ_WIDTH 100
#define BUZZ_HEIGHT 100

#endif

