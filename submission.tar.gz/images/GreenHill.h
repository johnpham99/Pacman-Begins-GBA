/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 GreenHill GreenHill.png 
 * Time-stamp: Sunday 11/07/2021, 17:19:47
 * 
 * Image Information
 * -----------------
 * GreenHill.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GREENHILL_H
#define GREENHILL_H

extern const unsigned short GreenHill[38400];
#define GREENHILL_SIZE 76800
#define GREENHILL_LENGTH 38400
#define GREENHILL_WIDTH 240
#define GREENHILL_HEIGHT 160

#endif

