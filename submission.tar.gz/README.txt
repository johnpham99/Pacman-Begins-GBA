This program is a simple maze game. 
The objective is to reach the end of the maze (white) without touching the walls (blue).
The D-PAD(arrow keys) is used for movement and are the only buttons used in gameplay.
Enter is the start button, so whenever you are prompted to "press Start", press Enter.
At any time in the game, you can press the select button (backspace), to restart the game (go back to title screen).
